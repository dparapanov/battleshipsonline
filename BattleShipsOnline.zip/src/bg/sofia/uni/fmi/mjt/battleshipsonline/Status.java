package bg.sofia.uni.fmi.mjt.battleshipsonline;

public enum Status {
	NO_HIT,
	HIT,
	DESTROYED,
	HIT_WATER
}
