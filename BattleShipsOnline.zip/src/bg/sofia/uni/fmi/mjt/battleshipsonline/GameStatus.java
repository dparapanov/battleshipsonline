package bg.sofia.uni.fmi.mjt.battleshipsonline;

public enum GameStatus {
	PENDING, IN_PROGRESS, FINISHED;
}
